var passMatch = 0;
//var nama,nim,rig,judul_ta="";

function checkPassword() {
    if (document.getElementsByName('password')[0].value != document.getElementsByName('confirm_password')[0].value) {
        document.getElementById('check-password').style.color = 'red';
        document.getElementById('check-password').innerHTML = 'Kata Sandi Tidak Sama';
        passMatch = 0;
    }else{
        document.getElementById('check-password').innerHTML = '';
        passMatch=1;
    }
}

function masuk() {
    notFound=1;
    daftar_akun = JSON.parse(localStorage.getItem('daftar_akun'));
    for (i in daftar_akun){
        nama = daftar_akun[i].nama;
        nim = daftar_akun[i].nim;
        rig = daftar_akun[i].rig;
        judul_ta = daftar_akun[i].judul_ta;
        if (daftar_akun[i].email==document.getElementsByName('email')[0].value 
        && daftar_akun[i].password==document.getElementsByName('password')[0].value) {
            notFound=0;
            alert("Selamat datang "+daftar_akun[i].nama+" !");
            location.href="index.html";
            break;
        }
    }
    if (notFound==1){
        alert("Username / Password Salah");
    }
}

function test() {
    return nama;
}

function daftar() {
    if (passMatch == 0){
        alert("Kata Sandi dengan Konfirmasi Kata Sandi tidak sama");
    }else{
        var email = document.getElementsByName('email')[0].value;
        var password =document.getElementsByName('password')[0].value;
        var nama = document.getElementsByName('name')[0].value;
        var nim = document.getElementsByName('nim')[0].value;
        var rig = document.getElementsByName('rig')[0].value;
        var judul_ta = document.getElementsByName('judul_ta')[0].value;

        if (localStorage.daftar_akun && localStorage.id_akun){
            daftar_akun = JSON.parse(localStorage.getItem('daftar_akun'));
            id_akun = parseInt(localStorage.getItem('id_akun'));
        }
        else {
            daftar_akun = [];
            id_akun = 0;
        }

        id_akun ++;
        daftar_akun.push({'id_akun':id_akun, 'email':email, 'password':password, 'nama':nama, 'nim':nim, 'rig':rig, 'judul_ta':judul_ta});
        localStorage.setItem('daftar_akun', JSON.stringify(daftar_akun));
        localStorage.setItem('id_akun', id_akun);
        alert("Pendaftaran Berhasil");
        location.href="login.html";
    }
}

function muatDaftarData(){
    if (localStorage.daftar_data && localStorage.id_data){
    
        daftar_data = JSON.parse(localStorage.getItem('daftar_data'));
       
        var data_app = "";
        
        if (daftar_data.length > 0){
            data_app = '<table class="table">';
            data_app += '<thead>'+
                                '<th>ID</th>'+
                                '<th>Nama</th>'+
                                '<th>NIM</th>'+
                                '<th>Rig</th>'+
                                '<th>Judul TA</th>'+
                                '<th>PU</th>'+
                                '<th>PP</th>'+
                                '<th>aksi</th>'+
                                '<th>aksi 2</th>'+
                              '</thead><tbody>';
                              
            for (i in daftar_data){
                data_app += '<tr>';
                data_app += '<td>'+ daftar_data[i].id_data + ' </td>'+
                                  '<td>'+ daftar_data[i].nama + ' </td>'+
                                  '<td>'+ daftar_data[i].nim + ' </td>'+
                                  '<td>'+ daftar_data[i].rig + ' </td>'+
                                  '<td>'+ daftar_data[i].judul + ' </td>'+
                                  '<td>'+ daftar_data[i].pem1 + ' </td>'+
                                  '<td>'+ daftar_data[i].pem2 + ' </td>'+
                                  '<td><a class="btn btn-danger btn-small" href="javascript:void(0)" onclick="hapusData(\''+daftar_data[i].id_data+'\')">Hapus</a></td>'+
                                  '<td><a class="btn btn-warning btn-small" href="javascript:void(0)" onclick="editData(\''+daftar_data[i].id_data+'\')">Edit</a></td>';
                data_app += '</tr>';
                
            }
           data_app += '</tbody></table>';
       
        }
        else {
            data_app = "Tidak ada data...";
        }
       
       $('#list-data').html(data_app);
       $('#list-data').hide();
       $('#list-data').fadeIn(100);
    }
}

function editData(id){
		
    if (localStorage.daftar_data && localStorage.id_data){
        daftar_data = JSON.parse(localStorage.getItem('daftar_data'));			
        idx_data = 0;
        for (i in daftar_data){
            if (daftar_data[i].id_data == id){
                $("#eid_data").val(daftar_data[i].id_data);
                $("#enama").val(daftar_data[i].nama);
                $("#enim").val(daftar_data[i].nim);
                $("#eemail").val(daftar_data[i].email);
                $("#erig").val(daftar_data[i].rig);
                $("#epassword").val(daftar_data[i].password);
                $("#ejudul").val(daftar_data[i].judul);
                $("#epem1").val(daftar_data[i].pem1);
                $("#epem2").val(daftar_data[i].pem2);
                daftar_data.splice(idx_data, 1);
            }
            idx_data ++;
        }
        gantiMenu('edit-data');
        
    }
    
}


function simpanData(){
    nama = $('#nama').val();
    nim = $('#nim').val();
    email = $('#email').val();
	rig = $('#rig').val();
	password = $('#password').val();
	judul = $('#judul').val();
	pem1 = $('#pem1').val();
	pem2 = $('#pem2').val();
    
    if (localStorage.daftar_data && localStorage.id_data){
        daftar_data = JSON.parse(localStorage.getItem('daftar_data'));
        id_data = parseInt(localStorage.getItem('id_data'));
    }
    else {
        daftar_data = [];
        id_data = 0;
    }

    id_data ++;
    daftar_data.push({'id_data':id_data, 'nama':nama, 'nim':nim, 'rig':rig, 'judul':judul, 'pem1':pem1, 'pem2':pem2});
    localStorage.setItem('daftar_data', JSON.stringify(daftar_data));
    localStorage.setItem('id_data', id_data);
    document.getElementById('form-data').reset();
    gantiMenu('list-data');
    
    return false;
}

function simpanEditData(){
    var id_data = $('#eid_data').val();
    var nama = $('#enama').val();
    var nim = $('#enim').val();
    var email = $('#eemail').val();
    var rig = $('#erig').val();
    var password = $('#epassword').val();
    var judul = $('#ejudul').val();
    var pem1 = $('#epem1').val();
    var pem2 = $('#epem2').val();
    
    
    daftar_data.push({'id_data':id_data, 'nama':nama, 'nim':nim, 'email':email, 'rig':rig,'password':password, 'judul':judul, 'pem1':pem1, 'pem2':pem2});
    localStorage.setItem('daftar_data', JSON.stringify(daftar_data));
    document.getElementById('eform-data').reset();
    gantiMenu('list-data');
    
    return false;
}

function hapusData(id){
    if (localStorage.daftar_data && localStorage.id_data){
        daftar_data = JSON.parse(localStorage.getItem('daftar_data'));
        
        idx_data = 0;
        for (i in daftar_data){
            if (daftar_data[i].id_data == id){
                daftar_data.splice(idx_data, 1);
            }
            idx_data ++;
        }
       
        localStorage.setItem('daftar_data', JSON.stringify(daftar_data));
        muatDaftarData();
    }
}


function gantiMenu(menu){
    if (menu == "list-data"){
        muatDaftarData();
        $('#tambah-data').hide();
        $('#list-data').fadeIn();
        $('#edit-data').hide();
    }
    else if (menu == "tambah-data"){
        $('#tambah-data').fadeIn();
        $('#list-data').hide();
        $('#edit-data').hide();
    }else if (menu == "edit-data"){
        $('#edit-data').fadeIn();
        $('#tambah-data').hide();
        $('#list-data').hide();
    }
}